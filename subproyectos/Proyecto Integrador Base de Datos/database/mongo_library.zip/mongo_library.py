import pymongo
from typing import List, Dict, Any

# Configuración conceptual de la conexión a MongoDB
MONGO_URI = "mongodb://user_app_reader:password_segura@localhost:27017/demand_db?authSource=admin"
DATABASE_NAME = "demand_db"

class MongoLibrary:
    """
    Librería de acceso a datos para la base de datos NoSQL (MongoDB).
    Requiere la instalación de 'pymongo'.
    """
    def __init__(self, uri: str = MONGO_URI, db_name: str = DATABASE_NAME):
        self.client = None
        self.db = None
        try:
            # La conexión es conceptual, el usuario deberá adaptar la URI
            self.client = pymongo.MongoClient(uri, serverSelectionTimeoutMS=5000)
            # Intentar una operación para verificar la conexión (se lanzará una excepción si falla)
            self.client.admin.command('ping')
            self.db = self.client[db_name]
            print("Conexión a MongoDB establecida (Conceptual).")
        except pymongo.errors.ConnectionError as e:
            print(f"Error de conexión a MongoDB: {e}. Asegúrese de que el servidor esté corriendo y la URI sea correcta.")
        except Exception as e:
            print(f"Error inesperado al inicializar MongoLibrary: {e}")

    def get_collection_list(self) -> List[str]:
        """Devuelve una lista de todas las colecciones en la base de datos."""
        if self.db:
            return self.db.list_collection_names()
        return []

    # --- Funciones para la colección 'historical_sales' ---

    def get_historical_sales(self, query: Dict[str, Any] = None, limit: int = 100) -> List[Dict[str, Any]]:
        """Recupera documentos de ventas históricas."""
        if not self.db: return []
        collection = self.db["historical_sales"]
        return list(collection.find(query or {}).limit(limit))

    def insert_historical_sale(self, document: Dict[str, Any]) -> Any:
        """Inserta un nuevo documento de venta histórica."""
        if not self.db: return None
        collection = self.db["historical_sales"]
        result = collection.insert_one(document)
        return result.inserted_id

    # --- Funciones para la colección 'active_forecasts' ---

    def get_active_forecasts(self, query: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        """Recupera todos los documentos de pronósticos activos."""
        if not self.db: return []
        collection = self.db["active_forecasts"]
        return list(collection.find(query or {}))

    def insert_forecasts_batch(self, documents: List[Dict[str, Any]]) -> List[Any]:
        """Inserta un lote de nuevos pronósticos."""
        if not self.db: return []
        collection = self.db["active_forecasts"]
        result = collection.insert_many(documents)
        return result.inserted_ids

    def close_connection(self):
        """Cierra la conexión con el cliente de MongoDB."""
        if self.client:
            self.client.close()
            print("Conexión a MongoDB cerrada.")

# Ejemplo de uso (conceptual)
# if __name__ == '__main__':
#     # Nota: Este código fallará si MongoDB no está corriendo localmente con la configuración de la URI.
#     # Es un ejemplo de la estructura de la librería.
#     library = MongoLibrary()
#     
#     print("\n--- Listado de Colecciones (Conceptual) ---")
#     collections = library.get_collection_list()
#     print(collections)
#     
#     # Simulación de un nuevo pronóstico
#     # new_forecast = {
#     #     "producto": "PROD_TEST_MONGO",
#     #     "cliente": "CLI_TEST_MONGO",
#     #     "fecha_pronostico": "2026-01-01",
#     #     "ensemble": 150.5
#     # }
#     # if library.db:
#     #     inserted_id = library.insert_historical_sale(new_forecast)
#     #     print(f"\nID insertado: {inserted_id}")
#     
#     library.close_connection()
