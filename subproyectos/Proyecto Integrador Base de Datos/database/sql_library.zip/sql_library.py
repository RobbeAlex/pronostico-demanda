import sqlite3
import pandas as pd
from typing import List, Dict, Any

# Definición de la ruta a la base de datos
DB_PATH = "Collins_Demand_DB.db"

class SQLLibrary:
    """
    Librería de acceso a datos para la base de datos SQL (SQLite).
    Encapsula la lógica de conexión y las operaciones CRUD.
    """
    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path

    def _execute_query(self, query: str, params: tuple = ()) -> List[Dict[str, Any]]:
        """Ejecuta una consulta de lectura y devuelve los resultados como una lista de diccionarios."""
        conn = None
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row # Permite acceder a las columnas por nombre
            cursor = conn.cursor()
            cursor.execute(query, params)
            
            # Convertir los resultados a una lista de diccionarios
            results = [dict(row) for row in cursor.fetchall()]
            return results
        except sqlite3.Error as e:
            print(f"Error al ejecutar la consulta: {e}")
            return []
        finally:
            if conn:
                conn.close()

    def _execute_dml(self, query: str, params: tuple = ()) -> bool:
        """Ejecuta una consulta de manipulación de datos (INSERT, UPDATE, DELETE)."""
        conn = None
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute(query, params)
            conn.commit()
            return True
        except sqlite3.Error as e:
            print(f"Error al ejecutar DML: {e}")
            if conn:
                conn.rollback()
            return False
        finally:
            if conn:
                conn.close()

    # --- Funciones de Lectura (READ) ---

    def get_historical_sales(self, limit: int = 100) -> pd.DataFrame:
        """Recupera datos históricos de ventas."""
        query = f"SELECT * FROM ventas_historicas LIMIT {limit}"
        data = self._execute_query(query)
        return pd.DataFrame(data)

    def get_active_forecasts(self) -> pd.DataFrame:
        """Recupera todos los pronósticos activos."""
        query = "SELECT * FROM pronosticos_activos"
        data = self._execute_query(query)
        return pd.DataFrame(data)

    # --- Funciones de Escritura (WRITE) ---

    def insert_forecasts(self, forecasts: List[Dict[str, Any]]) -> bool:
        """Inserta una lista de nuevos pronósticos en la tabla pronosticos_activos."""
        if not forecasts:
            return True

        # Asumiendo que todos los diccionarios tienen las mismas claves
        keys = forecasts[0].keys()
        columns = ", ".join(keys)
        placeholders = ", ".join(["?"] * len(keys))
        
        query = f"INSERT INTO pronosticos_activos ({columns}) VALUES ({placeholders})"
        
        # Preparar los valores para la ejecución por lotes
        values = [tuple(f.values()) for f in forecasts]
        
        conn = None
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.executemany(query, values)
            conn.commit()
            return True
        except sqlite3.Error as e:
            print(f"Error al insertar pronósticos: {e}")
            if conn:
                conn.rollback()
            return False
        finally:
            if conn:
                conn.close()

# Ejemplo de uso (descomentar para probar)
# if __name__ == '__main__':
#     # Nota: Para que este ejemplo funcione, el archivo Collins_Demand_DB.db debe estar en el mismo directorio
#     library = SQLLibrary()
#     
#     print("--- Ventas Históricas (Primeras 5 filas) ---")
#     df_sales = library.get_historical_sales(limit=5)
#     print(df_sales)
#     
#     print("\n--- Pronósticos Activos ---")
#     df_forecasts = library.get_active_forecasts()
#     print(f"Total de pronósticos: {len(df_forecasts)}")
#     
#     # Ejemplo de inserción (simulado)
#     # new_forecasts = [
#     #     {
#     #         "Producto_Descripcion": "PROD_TEST_1",
#     #         "Cliente_Descripcion": "CLI_TEST_1",
#     #         "Cluster": 1,
#     #         "Fecha_Pronostico": "2026-01-01 00:00:00",
#     #         "Pronostico_Ensemble_PedidoPiezas": 150.5,
#     #         "Pronostico_Min": 140.0,
#     #         "Pronostico_Max": 160.0
#     #     }
#     # ]
#     # if library.insert_forecasts(new_forecasts):
#     #     print("\nInserción de pronóstico de prueba exitosa.")
#     # else:
#     #     print("\nFallo en la inserción de pronóstico de prueba.")
